Including continuing from 8_bit_align folder to include fifo in the FSM in this folder.
First will be loop_back+FIFO followed by the two different device FIFOs.